<?php return array('dependencies' => array(), 'version' => 'acd3356aaf9b3e68af2a');
