<?php return array('dependencies' => array(), 'version' => 'fbedca629598b02773e0');
